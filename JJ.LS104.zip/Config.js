/*
Configuration here!
Code by Dacal -- Modified by Schnedi  // D0 NOT REMOVE THIS LINE //
*/

var Clock = "12h";		 // choose between "12h" or "24h".
var lang = "en";		     // choose between "sp", "en", "de" or "fr".